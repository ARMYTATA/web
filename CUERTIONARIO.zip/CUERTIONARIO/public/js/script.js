// Inicializar Firebase
const firebaseConfig = {
    apiKey: "AIzaSyB8ACKY49FUdCuttc5gzxefpxMFBeLjpqU",
    authDomain: "grupo-53.firebaseapp.com",
    databaseURL: "https://grupo-53-default-rtdb.firebaseio.com/",
    projectId: "grupo-53",
    storageBucket: "grupo-53.firebasestorage.app",
    messagingSenderId: "631385813690",
    appId: "1:631385813690:web:97fc54d965853aa98e4883",
    measurementId: "G-113T2YKX0S"
};

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

// Capturar datos del cuestionario y enviarlos a Firebase
document.getElementById("questionnaire").addEventListener("submit", function(event) {
    event.preventDefault();

    let respuestas = {};
    let elementos = document.querySelectorAll('input[type="radio"]:checked');

    elementos.forEach(input => {
        respuestas[input.name] = parseInt(input.value);
    });

    // Validar que todas las preguntas hayan sido contestadas
    if (Object.keys(respuestas).length < 10) {
        alert("Por favor, responde todas las preguntas antes de enviar.");
        return;
    }

    // Guardar respuestas en Firebase con un timestamp
    database.ref("respuestas/").push({
        respuestas,
        timestamp: new Date().toISOString()
    }).then(() => {
        alert("Respuestas enviadas correctamente.");
        document.getElementById("questionnaire").reset();
    }).catch(error => {
        console.error("Error al guardar los datos: ", error);
        alert("Hubo un error al enviar las respuestas.");
    });
});
